<template>
  <b-container id="mainImage">
    <div id="font">
      <h2 id="top">Happy House</h2>
      <b-img :src="require('@/assets/main_img.jpg')" fluid-grow></b-img>
    </div>
    <div id="font">
      <br />
      <b-row>
        <b-col cols="4" aling="left">
          <b-img :src="require('@/assets/main.jpg')" fluid-grow></b-img>
        </b-col>
        <b-col cols="4" aling="left">
          오늘의 뉴스
          <hr />
          <news></news>
        </b-col>
        <b-col cols="4" aling="right">
          주택 관련 기사
          <hr />
          <fiction></fiction>
        </b-col>
      </b-row>
    </div>
  </b-container>
</template>
<script>
import News from "@/components/news/news.vue";
import Fiction from "@/components/fiction/fiction.vue";
export default {
  name: "newsview",
  components: {
    News,
    Fiction,
  },
};
</script>
<style>
@font-face {
  font-family: "CookieRunOTF-Bold";
  src: url("https://cdn.jsdelivr.net/gh/projectnoonnu/noonfonts_twelve@1.0/CookieRunOTF-Bold00.woff")
    format("woff");
  font-weight: normal;
  font-style: normal;
}
#font {
  font-family: CookieRunOTF-Bold;
}

#top {
  margin: 30px;
}
</style>

