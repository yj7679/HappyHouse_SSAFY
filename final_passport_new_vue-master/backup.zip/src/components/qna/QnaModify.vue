<template>
  <b-container id="mainImage">
    <div id="font">
      <write-form type="modify" />
    </div>
  </b-container>
</template>

<script>
import WriteForm from "@/components/qna/WriteForm.vue";

export default {
  name: "qnamodify",
  components: {
    WriteForm,
  },
};
</script>
