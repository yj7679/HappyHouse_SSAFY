<template>
  <b-container id="mainImage">
    <div id="font">
      <write-form type="create" />
    </div>
  </b-container>
</template>

<script>
import WriteForm from "@/components/qna/WriteForm.vue";

export default {
  name: "qnacreate",
  components: {
    WriteForm,
  },
};
</script>
<style>
</style>