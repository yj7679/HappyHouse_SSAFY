<template>
  <div id="font">
    <b-container v-if="apts && apts.length != 0" class="bv-example-row mt-3">
      <apt-list-item v-for="(apt, index) in apts" :key="index" :apt="apt" />
    </b-container>
    <b-container v-else class="bv-example-row mt-3">
      <b-row>
        <b-col><b-alert show>아파트 목록이 없습니다.</b-alert></b-col>
      </b-row>
    </b-container>
    <b-container class="bv-example-row mt-3">
      <b-row>
        <b-col><b-alert show>해당 동 노인 시설이 없습니다.</b-alert></b-col>
      </b-row>
    </b-container>
    <b-container class="bv-example-row mt-3">
      <b-row>
        <b-col><b-alert show>원하시는 식당이 없습니다.</b-alert></b-col>
      </b-row>
    </b-container>

  </div>

</template>
<script>
import { mapState } from 'vuex';
import AptListItem from '@/components/house/AptListItem.vue';

export default {
  name: 'AptList',
  components: {
    AptListItem,
  },
  mounted:{
    
  },
  computed: {
    ...mapState(['apts']),
  },
};
</script>

<style></style>

