<template>
  <div id="app">
    <div class="dropdown bg-dark">

      <div class="text-center">
				<div class="dropdown bg-dark">
					<div class="btn-group">
						<div class="text-white mr-2"> 도시
              <select class="btn btn-light p-1" v-model="selectedSido" @change="makeGugunBtn">
                <option v-for="(city,index) in cities" :key="index" :value=city.sido_code>{{city.sido_name}}</option>
              </select>
            </div>
						

					</div>
					<div class="btn-group">
					  <div class="text-white mr-2"> 구
              <select class="btn btn-light p-1" v-model="selectedGugun" @change="makeDongBtn">
                <option v-for="(gugun,index) in guguns" :key="index" :value=gugun.gugun_code>{{gugun.gugun_name}}</option>
              </select>
            </div>
					</div>
					<div class="btn-group">
					  <div class="text-white mr-2"> 동
              <select class="btn btn-light p-1" v-model="selectedDong" @change="selectComplete">
                <option v-for="(dong,index) in dongs" :key="index" :value=dong.dongcode>{{dong.dong}}</option>
              </select>
            </div>
					</div>
				</div>
			</div>
 
		</div>

    <div id="map" style="width:750px;height:400px;"></div>

  </div>
</template>

<script>

import http from "@/util/http-common";


import { mapActions} from "vuex";


  export default {
    data(){
      return{
        cities:[],
        guguns:[],
        dongs:[],
        dong:[],
        gus:[],
        marker:Object,
        map:Object,
        lat: "",
        selectedGugun:'',
        selectedSido:'',
        selectedDong:'',
      }
      
    },

    created(){
      //this.$store.dispatch("getHouses");
    },
    mounted() {
      window.kakao && window.kakao.maps ? this.initMap() : this.addScript();
      this.makeCityBtn();
    },

    methods : {
      ...mapActions(["getAptList"]),
      initMap() {
        var container = document.getElementById('map');
        var options = {
          center: new kakao.maps.LatLng(33.450701, 126.570667),
          level: 3
        };
        this.map = new kakao.maps.Map(container, options); //마커추가하려면 객체를 아래와 같이 하나 만든다.
        this.marker = new kakao.maps.Marker({ position: this.map.getCenter() });
        this.makeMarkers();
        this.marker.setMap(this.map);
      },
      addScript() {
        const script = document.createElement('script'); /* global kakao */
        script.onload = () => kakao.maps.load(this.initMap);
        script.src = 'http://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=8c67ac9e956ca48f79dcf1740da2647e';
        document.head.appendChild(script);
      },
      makeCityBtn(){
        this.$store.dispatch("getCities");
        this.cities=this.$store.state.cities;
      },

      makeGugunBtn(){
        http
          .get(`/map/sido/${this.selectedSido}`, {
            selectedSido: this.selectedSido
          })
        .then(({ data }) => {
          //context.commit("SET_SIDO", payload);
         // console.log("1");
          this.guguns=data;
          //console.log(payload);
          //console.log(data);
        })
        
      },
      makeDongBtn(){
        http
          .get(`/map/gugun/${this.selectedGugun}`, {
            selectedGugun: this.selectedGugun
          })
        .then(({ data }) => {
          //context.commit("SET_SIDO", payload);
          //console.log("1");
          this.dongs=data;
          //console.log(payload);
          //console.log(data);
        })
      },

      //세개의 동이 다 클릭 된 경우 실행 함수
      selectComplete(){
        http
          .get(`/map/dong/${this.selectedDong}`, {
            selectedDong: this.selectedDong
          })
        .then(({ data }) => {
          //context.commit("SET_SIDO", payload);
          this.dong=data;
          console.log(data);
          //console.log(payload);

          if (this.selectedDong) this.getAptList(this.selectedDong);
          // this.$store.dispatch('getAptList', this.dongCode);
        });


        //console.log(this.selectedSido);
        //console.log(this.selectedGugun);
        //console.log(this.selectedDong);

      },
      makeMarkers(){
        // 마커를 표시할 위치와 title 객체 배열입니다 
        var positions = [
            {
                title: '카카오', 
                latlng: new kakao.maps.LatLng(33.450705, 126.570677)
            },
            {
                title: '생태연못', 
                latlng: new kakao.maps.LatLng(33.450936, 126.569477)
            },
            {
                title: '텃밭', 
                latlng: new kakao.maps.LatLng(33.450879, 126.569940)
            },
            {
                title: '근린공원',
                latlng: new kakao.maps.LatLng(33.451393, 126.570738)
            }
        ];

      // 마커 이미지의 이미지 주소입니다
      var imageSrc =
        "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png";

      for (var i = 0; i < positions.length; i++) {
        // 마커 이미지의 이미지 크기 입니다
        var imageSize = new kakao.maps.Size(24, 35);

        // 마커 이미지를 생성합니다
        var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);

        // 마커를 생성합니다
        this.marker = new kakao.maps.Marker({
          map: this.map, // 마커를 표시할 지도
          position: positions[i].latlng, // 마커를 표시할 위치
          title: positions[i].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
          image: markerImage, // 마커 이미지
        });
      }
    },
  },
};

</script>

