<template>
  <div id="left_menu">
    <h3>주위시설</h3>
    

    <div>
      <h3>음식 키워드 입력</h3>
      <input type="text" placeholder="ex) 된장찌개" />
    </div>
  </div>
</template>