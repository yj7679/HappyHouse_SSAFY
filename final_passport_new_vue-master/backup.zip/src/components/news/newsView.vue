<template>
  <b-container id="mainImage">
    <div class="regist" id="font">
      <br />
      <h1 class="underline title">뉴스 정보</h1>
      <br />
      <div class="regist_form">
        <h1>{{ singlenews.title }} <br /></h1>
        <h3>출처 : {{ singlenews.editer }}</h3>
      </div>
      <div>
        <br />
        자세히 보기
        <br />
        <a v-bind:href="singlenews.link">{{ singlenews.link }}</a>
      </div>
      <br />
      <router-link to="/" class="btn"
        ><button id="btn_group" class="btn">목록</button></router-link
      >
    </div>
  </b-container>
</template>

<script>
import { mapGetters } from "vuex";

export default {
  name: "newsdetial",
  computed: {
    ...mapGetters(["singlenews"]),
  },

  data() {
    return {
      isbn: "",
      title: "",
      link: "",
      editer: "",
    };
  },
  created() {
    this.isbn = this.$route.query.isbn;
    this.$store.dispatch("getSingleNews", `/news/${this.isbn}`);
  },
  methods: {},
};
</script>
<style scoped>
.regist {
  padding: 10px;
}
.regist_form {
  text-align: left;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
input,
textarea,
.view {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  color: #787878;
  font-size: medium;
}
#btn_group {
  border: 1px solid skyblue;
  background-color: rgba(0, 0, 0, 0);
  color: skyblue;
  padding: 5px;
  width: 150px;
}

#btn_group:hover {
  color: white;
  background-color: skyblue;
}

h1 {
  text-align: center;
}

h3 {
  text-align: right;
}
</style>
